#!/bin/sh

#-------------------------------------------------------------------------------
#
#  Name:
#	hepspec-systeminfo.sh [HEP-SPEC06 score]
#
#  Description:
#	This script tries to gather some important details about the system
#	under test (e.g., when computing the HEP-SPEC06 benchmark). The
#	output is formatted using dokuwiki syntax, so the results can be
#	simply copy and pasted into the HEP-SPEC06 results pages at CASPUR
#	(https://hepix.caspur.it/benchmarks/).
#
#  Requirements:
#	This script runs the "dmidecode" command which requires root
#	privileges. If you don't want to run this script as root, then it
#	is sufficient to save the output of the "dmidecode" command into
#	a file named "dmidecode-output" located in the current working
#	directory.
#
#  Programming language:
#	BASH (yes, I'm a shell guy :-)
#
#  Known issues:
#	1. Some systems don't report the right configuration of the memory.
#	   -->	Fixed by using "free" instead of "dmidecode" if necessary.
#	2. I don't see a common way how the type and the speed of the memory
#	   are reported, e.g. "DDR2-667".
#	   -->	We only try to figure out the number and the total capacity
#		of the modules. Please, add the appropriate info.
#	3. On some systems the "dmidecode" command reports wrong details
#	   about the size of the L1, L2, and L3 CPU caches.
#	   -->	Please, check the results very carefully before you copy
#		and paste it into the HEP-SPEC06 results wiki page.
#	4. The L1 cache is often split into an instruction cache and a data
#	   cache. However, the "dmidecode" command doesn't take care of these
#	   details.
#	   -->	We don't report the L1 cache size.
#	5. The type of the baseboard is only available, if you run this
#	   command on a "whitebox".
#	   -->	For branded systems, insert the name of the system, e.g.
#		"IBM x3550" or "HP ProLiant DL360 G4p".
#	6. "Socket Designation: Not Specified" in Cache Information
#	   when running the command on DELL PowerEdge 1950. Checking next
#	   line ("Configuration") instead.
#	7. The dmidecode command reports a flash type memory device if it
#	   is run on a Supermicro X8DTT system. This has to be excluded from
#	   the installed memory count.
#
#  Author:
#	Manfred Alef, GridKa
#
#  Version:
#	2009-04-30	Release 1.0
#	2009-05-04	Release 1.1 MA (AI, cache size)
#	2009-06-12	Release 1.2 MA (GM, disabled cache)
#	2009-06-15	Release 1.3 MA (GM, system info, vendor info improved)
#	2009-08-04	Release 1.4 MA (Excluding flash type memory device)
#
#-------------------------------------------------------------------------------


#  Run "dmidecode" command or use output file, if already available:

if [ $USER == root ]; then
  [ -f dmidecode-output ] || dmidecode > dmidecode-output
else
  [ -r dmidecode-output ] || ( echo "Cannot find dmidecode info!" ; echo "Run this script as root, or run this command first:" ; echo "	dmidecode > $PWD/dmidecode-output" ; exit 1 )
fi


#  Beautification of processor type:

model_name=$(grep "^model name" /proc/cpuinfo | head -1)
case $model_name in
  *\ Core\ AMD\ Opteron\(tm\)\ Processor\ *)
		cpu_type="AMD Opteron $(echo $model_name | cut -d" " -f9)" ;;
  *\ AMD\ Opteron\(tm\)\ Processor\ *)
		cpu_type="AMD Opteron $(echo $model_name | cut -d" " -f7)" ;;
  *\ Intel\(R\)\ Xeon\(TM\)\ CPU\ *GHz)
		cpu_type="Intel Xeon $(echo $model_name | tr -s " " | cut -d" " -f7)" ;;
  *\ Intel\(R\)\ Xeon\(R\)\ CPU\ *)
		cpu_type="Intel Xeon $(echo $model_name | tr -s " " | cut -d" " -f7)" ;;
  *)		cpu_type=$model_name ;;
esac
n_cores=$(grep -c "^model name" /proc/cpuinfo)


#  Browse through the output of the "dmidecode" command:

exec < dmidecode-output

clock_speed="0"
memory_modules="0"
memory="0"
l1_cache="0"
# Note: L1 cache is usually split into instruction cache and data cache.
#	Unfortunately it's not clearly reported by the dmidecode command.
#	Therefore we calculate but don't report the L1 cache size.
l2_cache="0"
l3_cache="0"

while read line ; do

  case "x$line" in

#  - Handles:

    x|xHandle\ 0x[0-9a-fA-F][0-9a-fA-F][0-9a-fA-F][0-9a-fA-F])
		block="" ;;

    xBase\ Board\ Information)
		[ "$block" ] && ( echo "Cannot resolve block-in-block statement" ; exit 2 )
		block=$line ;;

    xSystem\ Information)
		[ "$block" ] && ( echo "Cannot resolve block-in-block statement" ; exit 2 )
		block=$line ;;

    xProcessor\ Information)
		[ "$block" ] && ( echo "Cannot resolve block-in-block statement" ; exit 2 )
		block=$line ;;

    xCache\ Information)
		[ "$block" ] && ( echo "Cannot resolve block-in-block statement" ; exit 2 )
		#  Have to read the second input line in "Cache Information" block:
		read line || ( echo "Cannot read next line" ; exit 1 )
		read line || ( echo "Cannot read next line" ; exit 1 )
		case "x$line" in
		  x*Configuration:\ Enabled,*\ Level\ 1)	block="L1 Cache Information" ;;
		  x*Configuration:\ Enabled,*\ Level\ 2)	block="L2 Cache Information" ;;
		  x*Configuration:\ Enabled,*\ Level\ 3)	block="L3 Cache Information" ;;
		  x*Configuration:\ Disabled,*\ Level\ 1)	block="L1 Cache Disabled" ;;
		  x*Configuration:\ Disabled,*\ Level\ 2)	block="L2 Cache Disabled" ;;
		  x*Configuration:\ Disabled,*\ Level\ 3)	block="L3 Cache Disabled" ;;
		esac ;;

    xMemory\ Device)
		[ "$block" ] && ( echo "Cannot resolve block-in-block statement" ; exit 1 )
		block=$line ;;


#  - Items:

    xManufacturer:*)
		if [ "$block" == "Base Board Information" ]; then
		  manufacturer_1=$(echo $line | cut -d" " -f 2)
		elif [ "$block" == "System Information" ]; then
		  manufacturer_2=$(echo $line | cut -d" " -f 2)
		fi ;;

    xProduct\ Name:*)
		if [ "$block" == "Base Board Information" ]; then
		  [ "$product_name_1" ] || product_name_1=$(echo $line | cut -d" " -f 3-)
		elif [ "$block" == "System Information" ]; then
		  [ "$product_name_2" ] || product_name_2=$(echo $line | cut -d" " -f 3-)
		fi ;;

    xCurrent\ Speed:*)
		if [ "$block" == "Processor Information" ]; then
		  clock_speed_new=$(echo $line | cut -d" " -f 3)
		  if [ $clock_speed_new -gt $clock_speed ]; then
		    clock_speed=$clock_speed_new
		  fi
		fi ;;

    xInstalled\ Size:*)
		installed_size=$(echo $line | cut -d" " -f 3)
		if [ "$block" == "L1 Cache Information" ]; then
		  l1_cache="$l1_cache + $installed_size"
		  l1_cache_dimension=$(echo $line | cut -d" " -f 4)
		elif [ "$block" == "L2 Cache Information" ]; then
		  l2_cache="$l2_cache + $installed_size"
		  l2_cache_dimension=$(echo $line | cut -d" " -f 4)
		elif [ "$block" == "L3 Cache Information" ]; then
		  l3_cache="$l3_cache + $installed_size"
		  l3_cache_dimension=$(echo $line | cut -d" " -f 4)
#		else
#		  echo "Cannot resolve input line: $line" ; exit 2
		fi ;;

    xSize:\ No\ Module\ Installed)
		;;
    xSize:*)
		if [ "$block" == "Memory Device 64 or 72 bits" ]; then
		  installed_size=$(echo $line | cut -d" " -f 2)
		  memory_dimension=$(echo $line | cut -d" " -f 3)
		  let memory_modules=memory_modules+1
		  memory="$memory + $installed_size"
		fi ;;

    xData\ Width:\ 64\ bits|xData\ Width:\ 72\ bits)
		if [ "$block" == "Memory Device" ]; then
		  block="$block 64 or 72 bits"
		fi ;;

  esac

done


#  - Error handling:
#	Some systems don't correctly report the mounted RAM modules.
#	If "dmidecode" doesn't find memory modules, gather the
#	available memory size using the "free" command:

if [ "$memory" == "0" ]; then
  memory_by_free=$(free -m | grep ^Mem: | tr -s " " | cut -d " " -f 2)
  memory=$(expr $memory_by_free + 512)
  memory_modules="unknown"
fi
if [ "$manufacturer_1" ]; then
  manufacturer=$manufacturer_1
elif [ "$manufacturer_2" ]; then
  manufacturer=$manufacturer_2
else
  manufacturer="Manufacturer: unknown,"
fi
if [ "$product_name_1" ]; then
  product_name=$product_name_1
elif [ "$product_name_2" ]; then
  product_name=$product_name_2
else
  product_name="product name: unknown"
fi


#  Report results:

echo "
If you want to distribute to the HEP-SPEC06 benchmark results tables,
first choose the appropriate wiki:

Operating system: 	$(cat /etc/redhat-release)
Hardware platform:	$(uname -i)
Compiler:         	$(gcc -v 2>&1 | grep "^gcc version")

Then copy and paste this line to the wiki table:

^  $cpu_type  ^  ${1:-xx.xx} |  $clock_speed |  $(expr $l2_cache)+$(expr $l3_cache)  |  $n_cores  |  $(expr \( $memory \) / 1024) ($memory_modules modules)  | $manufacturer $product_name  | |

Note: please carefully check the results line above before publishing
as there are some known issues about the reported memory and cache size.
"


#-------------------------------------------------------------------------------
